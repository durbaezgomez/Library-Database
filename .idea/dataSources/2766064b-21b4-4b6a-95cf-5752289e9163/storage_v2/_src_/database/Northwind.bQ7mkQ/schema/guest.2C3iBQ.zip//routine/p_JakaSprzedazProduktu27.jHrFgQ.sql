create procedure p_JakaSprzedazProduktu27
	@IDProduct int = 0,
	@Total money output
as
	select @Total= sum(round(od.Quantity * od.UnitPrice * cast((1-od.Discount)as money),2))
	from [Order Details] od
	where ProductID = @IDProduct
go

