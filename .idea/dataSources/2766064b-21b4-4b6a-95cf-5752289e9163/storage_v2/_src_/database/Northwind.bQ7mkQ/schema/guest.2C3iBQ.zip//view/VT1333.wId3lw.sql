create view VT1333
as
select * from T1
where K1 > 1
go

