create view raport2
as
select year(OrderDate)as [year], count(o.CustomerID) as ilosc
from Orders o inner join Customers c
on o.CustomerID=c.CustomerID
group by year(OrderDate)
having count(o.CustomerID)>70
go

