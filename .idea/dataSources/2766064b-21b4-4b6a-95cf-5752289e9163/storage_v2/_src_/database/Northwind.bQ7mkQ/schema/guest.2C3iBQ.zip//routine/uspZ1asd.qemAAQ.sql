CREATE PROC uspZ1asd (@Cena MONEY)
AS
SELECT * FROM Products
WHERE UnitPrice >= @Cena
ORDER BY UnitPrice DESC, Productname
go

