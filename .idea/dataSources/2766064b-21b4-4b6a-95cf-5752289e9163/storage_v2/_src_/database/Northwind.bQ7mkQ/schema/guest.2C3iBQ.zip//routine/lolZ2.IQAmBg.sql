CREATE PROC lolZ2 (@NazwaKategorii VARCHAR(20), @ile INT OUTPUT)
AS
DECLARE @IdKategorii INT
DECLARE @MaksCena MONEY

SET @IdKategorii = (SELECT CategoryId FROM Categories WHERE CategoryName = @NazwaKategorii)
SET @MaksCena = (SELECT MAX(UnitPrice) FROM Products WHERE CategoryId = @IdKategorii)
SELECT * FROM Products
WHERE CategoryId = @IdKategorii AND UnitPrice = @MaksCena
SET @Ile = (SELECT COUNT(*) FROM Products WHERE CategoryId=@IdKategorii)
go

