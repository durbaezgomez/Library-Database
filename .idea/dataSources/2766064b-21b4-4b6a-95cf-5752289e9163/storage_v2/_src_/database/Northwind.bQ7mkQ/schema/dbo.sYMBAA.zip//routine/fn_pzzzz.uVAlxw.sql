create function dbo.fn_pzzzz
(@cid as nchar(5)) returns varchar(8000)
as 
begin 
declare @orders as varchar(8000);
set @orders = '';

select @orders = @orders + cast(orderid as varchar(10)) + ';'
from dbo.Orders
where customerid = @cid;

return @orders;
end
go

