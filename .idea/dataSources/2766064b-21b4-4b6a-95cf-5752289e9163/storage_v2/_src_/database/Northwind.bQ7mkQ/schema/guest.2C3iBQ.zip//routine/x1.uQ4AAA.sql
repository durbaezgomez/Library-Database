create proc x1
as 
declare @maksCena money
set @maksCena = (select max(unitprice) from products)
go

