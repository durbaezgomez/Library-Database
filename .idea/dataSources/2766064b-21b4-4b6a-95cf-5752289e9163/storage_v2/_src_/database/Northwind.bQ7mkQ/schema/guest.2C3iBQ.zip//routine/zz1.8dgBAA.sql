create proc zz1
as
declare @makscena money
set @makscena = (select max(unitprice) from products)
go

