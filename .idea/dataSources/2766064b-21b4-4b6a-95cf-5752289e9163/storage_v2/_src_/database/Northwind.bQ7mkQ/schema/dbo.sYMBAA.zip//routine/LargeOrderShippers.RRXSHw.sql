
create function dbo.LargeOrderShippers ( @FreightParm money )
returns @OrderShipperTab table
	(
	ShiperID int,
	ShipperName nvarchar(80),
	OrderID int,
	ShippedDate datetime,
	Freight money
	)
as 
begin
	insert into @OrderShipperTab
		select S.ShipperID, S.CompanyName, O.OrderID, O.ShippedDate, O.Freight
		from Shippers as S inner join Orders as O
		  on S.ShipperID = O.ShipVia
		where O.Freight > @FreightParm
	return
end
go

