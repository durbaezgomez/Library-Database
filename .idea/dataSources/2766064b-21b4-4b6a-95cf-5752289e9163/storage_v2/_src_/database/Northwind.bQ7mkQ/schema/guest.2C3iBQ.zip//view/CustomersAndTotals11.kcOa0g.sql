 CREATE VIEW CustomersAndTotals11 (CustomerID, Total)
 AS
 Select CustomerID,
 SUM(ROUND(Quantity*UnitPrice*
 CAST((1-Discount) AS MONEY),2))
 FROM [Order Details] OD JOIN Orders O
 ON OD.OrderID = O.OrderID
 GROUP BY CustomerID
 go

