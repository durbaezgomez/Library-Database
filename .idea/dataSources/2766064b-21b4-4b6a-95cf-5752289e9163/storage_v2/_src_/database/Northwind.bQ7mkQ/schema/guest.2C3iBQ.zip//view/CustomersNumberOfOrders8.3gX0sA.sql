--use Northwind
/*create view v6
as
select ProductID, ProductName, UnitPrice
from Products
where ProductName LIKE 'A%'
create view CustomersAndTotals (CustomerID, Total)
as
select CustomerID,
sum(round(Quantity*UnitPrice*
cast((1-Discount) as money),2))
from [Order Details] od join Orders o
on od.OrderID = o.OrderID
group by CustomerID
select * from CustomerAndTotals
order by Total DESC*/
create view CustomersNumberOfOrders8(CustomerID, NumberOfOrders)
as 
select CustomerID, count(*)
from Orders
group by CustomerID

--select * from CustomersNumberOfOrders
go

