create view VSd
as 
select ProductId, ProductName, UnitPrice
from Products
where ProductName like 'A%'
go

