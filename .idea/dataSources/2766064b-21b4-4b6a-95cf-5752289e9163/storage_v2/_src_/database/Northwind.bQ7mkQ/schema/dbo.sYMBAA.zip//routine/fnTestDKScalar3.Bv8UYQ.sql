CREATE FUNCTION dbo.fnTestDKScalar3 (@arg1 INT) RETURNS INT
BEGIN
	IF @arg1 = 1 return 1
	IF @arg1 = 2 return 1
	ELSE RETURN dbo.fnTestDKScalar2(@arg1 - 2) + dbo.fnTestDKScalar2(@arg1 - 1)
	RETURN 0
END
go

