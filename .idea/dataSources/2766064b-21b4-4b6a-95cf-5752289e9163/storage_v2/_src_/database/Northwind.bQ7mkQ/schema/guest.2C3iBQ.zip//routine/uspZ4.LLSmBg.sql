create proc uspZ4 (@Cena Money)
as
select * from dbo.Product
where UnitPrice>=@Cena
order by UnitPrice DESC, ProductName
go

