create procedure p_Wywolaj_JakaSprzedazProduktu27
	@IDProduct int
as 
	declare @Total_sum money
	exec p_JakaSprzedazProduktu27 @IDProduct, @Total_sum output
	select @Total_sum
go

