Create PROC uspZ98 (@NazwaKategorii NVARCHAR(15), @Ile INT OUTPUT)
AS 
DECLARE @IdKategorii INT
DECLARE @MaksCena MONEY
SET @IdKategorii = (SELECT CategoryID FROM Categories WHERE CategoryName=@NazwaKategorii)
SET @MaksCena = (SELECT MAX(UnitPrice) FROM Products
WHERE CategoryID = @IdKategorii)
go

