CREATE PROC Z123321
AS
DECLARE @johnCena MONEY
SET @johnCena = (SELECT MAX(UnitPrice) FROM Products)
SELECT * FROM Products
WHERE UnitPrice = @johnCena
go

