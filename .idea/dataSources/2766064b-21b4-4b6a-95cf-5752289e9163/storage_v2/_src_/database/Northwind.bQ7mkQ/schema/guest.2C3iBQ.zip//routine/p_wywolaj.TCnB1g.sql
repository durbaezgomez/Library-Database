CREATE PROC p_wywolaj
@idproduct  int
AS 
DECLARE @total_sum money
EXEC p_sprzedazProduktu @idproduct,  @total_sum OUTPUT
SELECT @total_sum
go

