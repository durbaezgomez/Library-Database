CREATE PROC Z22
AS
DECLARE @MaksCena MONEY
SET @MaksCena = (SELECT MAX(UnitPrice) FROM Products)
SELECT * FROM Products
WHERE UnitPrice = @MaksCena
go

