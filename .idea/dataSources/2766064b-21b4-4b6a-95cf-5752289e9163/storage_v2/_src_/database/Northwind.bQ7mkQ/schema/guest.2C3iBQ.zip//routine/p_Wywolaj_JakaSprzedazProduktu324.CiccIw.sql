CREATE PROCEDURE p_Wywolaj_JakaSprzedazProduktu324
	@IDProduct int
AS
	DECLARE @Total_sum money
	EXEC p_JakaSprzedazProduktu324 @IDProduct, @Total_sum OUTPUT
	SELECT @Total_sum
go

