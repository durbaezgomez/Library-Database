create view CustomersNumbersOfOrders(CustomerID, NumberOfOrders)
as
select CustomerID, count(*)
from Orders
group by CustomerID
go

