CREATE PROCEDURE p_Wywolaj_JakaSprzedazProduktu
@IDProduct int
AS
DECLARE @Total_sum money
EXEC p_JakaSprzedazProduktu @IDProduct, @Total_sum OUT
SELECT @Total_sum
go

