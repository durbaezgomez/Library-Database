CREATE VIEW CustomersNumberOfOrderskgzik(CustomerID, NumberOfOrders)

AS
SELECT CustomerID, COUNT(*)

FROM Orders
GROUP BY CustomerID
go

