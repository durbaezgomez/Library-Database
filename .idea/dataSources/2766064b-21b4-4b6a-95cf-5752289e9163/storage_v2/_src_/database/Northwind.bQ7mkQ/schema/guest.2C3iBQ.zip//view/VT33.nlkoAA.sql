create view VT33
as 
select * from T1
where K1>1
go

