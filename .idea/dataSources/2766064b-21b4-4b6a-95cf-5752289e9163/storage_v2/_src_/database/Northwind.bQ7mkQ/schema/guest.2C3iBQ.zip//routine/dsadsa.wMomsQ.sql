create proc dsadsa as declare @maxc MONEY set @maxc = (select max(UnitPrice) from Products)
go

