create proc Z199899 
as 
declare @maksCena money
set @maksCena=(select max(UnitPrice) from Products)
go

