CREATE FUNCTION dbo.fn_TestDKTable6 (@arg1 INT) RETURNS table AS RETURN (SELECT UnitPrice + @arg1 ChangedUnitPrice FROM Products)
go

