Create view CustomersAndTotals1 (CustomerID, Total)
as
Select CustomerID, 
Sum(round(quantity*unitPrice*
Cast ((1-discount) as money), 2))
From [order details] od join orders O 
ON OD.OrderID=O.orderID
group by customerID
go

