/*
create view v1
as
select ProductID, ProductName, UnitPrice
from Products
where ProductName like 'A%'*/

/*
select * from v1
order by UnitPrice desc*/

/*
create view CustomerAndTOTALSs (CustomerID, Total)
as
select CustomerID,
sum(round(Quantity*UnitPrice*cast((1-Discount) as money),2))
from [Order Details] od join Orders o
on od.OrderID = o.OrderID
group by CustomerID*/

--select * from CustomerAndTOTALSs

create view CustomersLiczbaZamowienn (kolumna1_custID, kol2_LiczbaZamowien)
as
select CustomerID, count(*)
from Orders
group by CustomerID
go

