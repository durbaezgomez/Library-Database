--use Northwind
create view v6
as
select ProductID, ProductName, UnitPrice
from Products
where ProductName LIKE 'A%'
go

