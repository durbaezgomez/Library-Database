create proc uspZhhjhj5(@NazwaKategorii nvarchar(15), @ile int output)
as
declare @IdKategorii int
declare @makscena money

set @IdKategorii = (select CategoryID from Categories
where CategoryName=@NazwaKategorii)

set @makscena = (select max(unitPrice) from dbo.Products
where CategoryId = @IdKategorii)
go

