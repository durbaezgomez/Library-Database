create proc uspZhhjhj2(@NazwaKategorii nvarchar(15), @ile int output)
as
declare @IdKategorii int
declare @makscena money
go

