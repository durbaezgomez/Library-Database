CREATE VIEW V9
AS
SELECT productid, productname, unitprice
FROM Products
WHERE ProductName LIKE '%A'
go

