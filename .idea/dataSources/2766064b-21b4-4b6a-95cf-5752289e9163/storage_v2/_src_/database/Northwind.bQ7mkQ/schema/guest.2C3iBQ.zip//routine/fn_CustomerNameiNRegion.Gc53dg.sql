CREATE FUNCTION fn_CustomerNameiNRegion
					(@RegionParameter nvarchar(30))
RETURNS table
AS
RETURN (
		SELECT CustomerID, CompanyName
		FROM Northwind.dbo.Customers
		WHERE Region = @RegionParameter
		)
go

