CREATE PROC ZAG
AS
DECLARE @maksCena MONEY
SET @maksCena = (SELECT MAX(UnitPrice) FROM Products)

SELECT * FROM Products
WHERE UnitPrice = @maksCena
go

