CREATE VIEW CustomersAndTotalsAG (CustomerID, Total)
AS 
SELECT CustomerID,
SUM(ROUND(Quantity*UnitPrice*CAST((1-Discount) AS MONEY),2))
FROM [Order Details] OD JOIN Orders O
ON OD.OrderID = O.OrderID
GROUP BY CustomerID
go

