CREATE PROC p_sprzedazProduktu
@idprodukt int = 0,
@total money OUTPUT

AS

SELECT @total = SUM(ROUND(OD.Quantity * OD.UnitPrice * CAST ((1-OD.Discount) AS MONEY),2))
FROM [Order Details] AS OD
WHERE ProductID=@idprodukt
go

