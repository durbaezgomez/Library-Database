/*
IF OBJECT_ID('DBO.uspZ0001','P') IS NOT NULL
DROP PROC DBO.usle
GO

CREATE PROC uspZ0001 (@Cena MONEY)
AS
SELECT * FROM dbo.Products
WHERE UnitPrice >= @Cena
ORDER BY UnitPrice DESC, ProductName
GO
*/

CREATE PROC Z0002
AS
DECLARE @maksCena MONEY
SET @maksCena = (SELECT MAX(UnitPrice) FROM Products)
SELECT * FROM Products
WHERE UnitPrice = @MaksCena
go

