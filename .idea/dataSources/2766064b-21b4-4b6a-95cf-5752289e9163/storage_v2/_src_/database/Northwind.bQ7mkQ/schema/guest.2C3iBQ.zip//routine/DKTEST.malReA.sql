CREATE PROC DKTEST(@CategoryName VARCHAR(15)) AS 
SELECT * FROM Products P LEFT JOIN Categories C ON P.CategoryID = C.CategoryID WHERE @CategoryName = C.CategoryName;
go

