create procedure p_Wywolaj_JakaSprzedazProduktu0
@IDProduct int 
as 
 declare @Total_Sum money
 exec p_JakaSprzedazProduktu0 @IDProduct, @Total_Sum output
 select @Total_Sum
go

