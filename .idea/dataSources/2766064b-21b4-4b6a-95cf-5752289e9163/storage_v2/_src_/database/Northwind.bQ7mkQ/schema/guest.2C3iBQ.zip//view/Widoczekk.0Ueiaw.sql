CREATE VIEW Widoczekk
AS
SELECT Orders.OrderDate, SUM(ROUND([Order Details].Quantity *[Order Details].UnitPrice 
* CAST((1-[Order Details].Discount)AS money),2)) AS SumaKwot, COUNT(Orders.OrderID) AS Liczba_zamowien
FROM Orders JOIN [Order Details] ON Orders.OrderID = [Order Details].OrderID
GROUP BY Orders.OrderDate
go

