/*if object_id('DBO.uspZ1','P') is not null
drop proc DBO.uspZ1
go*/
create proc uzzpZ1 (@cena money)
as 
select * from dbo.Products
where unitprice >= @cena
order by unitprice desc, ProductName
go

