create proc zs1
as 
declare @maksCena MONEY
SET @maksCena = (Select max(UnitPrice) from Products)
Select @maksCena = MAX(UnitPrice) from Products
go

