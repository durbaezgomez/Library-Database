CREATE PROC Z33
AS 
DECLARE @maksCena MONEY
SET @maksCena = (SELECT MAX(UnitPrice) FROM Products)
go

