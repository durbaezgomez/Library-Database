create view V_AVG(Average)
as
select avg(K2) from T1
go

