create proc uspZSE (@NazwaKategorii NVARCHAR(15), @Ile int out)
as declare @IdKategorii int 
declare @MaksCena MOney

set @IdKategorii = (Select Categoryid from categories 
					where CategoryName = @NazwaKategorii)

set @MaksCena = (Select Max(UnitPrice) from dbo.Products
				where CategoryID = @IdKategorii)

select * from Products
where CategoryId = @IdKategorii AND UnitPrice = @MaksCena

set @Ile = (select count (*) from Products
			where categoryID = @IdKategorii)
go

