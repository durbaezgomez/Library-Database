create proc uspasd3(@NazwaKategorii NVARCHAR(15), @Ile INT OUT)
as
declare @IdKategorii INT
declare @MaksCena MONEY

SET @IdKategorii = (SELECT CategoryID FROM Categories
where categoryName = @NazwaKategorii)

set @MaksCena = (SELECT MAX(UnitPrice) FROM dbo.Products
where CategoryID = @IdKategorii)

SELECT*FROM Products
where CategoryID=@IdKategorii and UnitPrice = @MaksCena
SET @ile = (Select count(*) FROM products WHERE CategoryID=@IdKategorii)
go

