create proc zz11
as declare @makscena money
set @makscena = (select max(unitprice) from products)
go

