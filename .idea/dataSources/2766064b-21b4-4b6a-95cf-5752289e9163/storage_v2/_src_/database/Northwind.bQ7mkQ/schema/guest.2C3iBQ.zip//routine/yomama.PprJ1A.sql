--WITH MyCTE (NrProduktu, Nazwa)
--AS
--(
--SELECT ProductID,ProductName FROM Products
--WHERE CategoryID = 1
--)
--SELECT COUNT(*) FROM MyCTE
--WHERE Nazwa LIKE 'C%'

CREATE PROC yomama
AS
DECLARE @maksCena MONEY
SET @maksCena = (SELECT MAX(UnitPrice) FROM Products)
SELECT * FROM Products
WHERE UnitPrice = @maksCena
go

