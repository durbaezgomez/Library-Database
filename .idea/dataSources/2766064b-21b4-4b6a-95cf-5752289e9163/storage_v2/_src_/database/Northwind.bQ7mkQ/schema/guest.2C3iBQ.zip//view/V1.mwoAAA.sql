CREATE VIEW V1 AS SELECT ProductID, ProductName, UnitPrice FROM Products WHERE ProductName LIKE 'A%'
go

