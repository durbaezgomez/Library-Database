Create View CAT (CustomerID, Total)
as
select CustomerID,
Sum(ROUND(Quantity*UnitPrice*CAst((1-Discount) AS MONEY),2))
from [Order Details] OD JOIN Orders O
On OD.OrderID = O.OrderID
GROUP BY CustomerID
go

