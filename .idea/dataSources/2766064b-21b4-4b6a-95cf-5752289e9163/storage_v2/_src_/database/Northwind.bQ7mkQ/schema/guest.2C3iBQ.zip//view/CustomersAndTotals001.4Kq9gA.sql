CREATE VIEW CustomersAndTotals001 (CustomerID, Total)
AS
SELECT CustomerID,
SUM(ROUND(Quantity*UnitPrice*
CAST((1-Discount) AS MONEY),2))
FROM [Order Details] OD JOIN Orders O
ON OD.OrderID = O.orderID
GROUP BY CustomerID

go

