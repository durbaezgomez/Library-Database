create view CustomerAndTotals (CustomerID, Total)

as 

select CustomerID,  sum(round(Quantity*UnitPrice*cast((1-Discount) as money),2)) 

from [Order Details] OD join Orders O

on OD.OrderID = O.OrderID 

group by CustomerID
go

