create function dbo.fn_KonkatenacjaZamowien127
	(@cid as nchar(5)) returns varchar(8000)
as 
begin
	declare @orders as varchar(8000);
	set @orders = '';

	select @orders = @orders + cast(orderID as varchar(10)) + ';'
	from Orders
	where CustomerID = @cid;

	return @orders;
end
go

