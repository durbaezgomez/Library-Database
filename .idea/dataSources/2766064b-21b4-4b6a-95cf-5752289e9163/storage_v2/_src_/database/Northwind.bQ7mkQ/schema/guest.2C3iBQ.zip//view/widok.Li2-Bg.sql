CREATE VIEW widok
AS
SELECT ProductID, ProductName, UnitPrice
FROM Products
Where ProductName Like 'A%'

go

