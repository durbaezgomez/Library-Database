CREATE FUNCTION LOS (@FreightParm MONEY)
RETURNS @OrderShipperTab TABLE
(
ShipperID int,
ShipperName nvarchar(80),
OrderID int,
ShipedDate datetime,
Freight money
)
AS
BEGIN
INSERT INTO @OrderShipperTab
SELECT s.ShipperID,s.CompanyName,
o.OrderID,o.ShippedDate,o.Freight
FROM Shippers AS s INNER JOIN ORDERS AS o
ON s.ShipperID=o.ShipVia
WHERE O.Freight>@FreightParm
RETURN
END
go

