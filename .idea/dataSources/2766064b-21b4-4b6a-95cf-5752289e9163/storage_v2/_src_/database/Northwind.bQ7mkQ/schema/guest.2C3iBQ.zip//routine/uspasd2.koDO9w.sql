create proc uspasd2(@NazwaKategorii NVARCHAR(15), @Ile INT OUT)
as
declare @IdKategorii INT
declare @MaksCena MONEY

SET @IdKategorii = (SELECT CategoryID FROM Categories
where categoryName = @NazwaKategorii)

set @MaksCena = (SELECT MAX(UnitPrice) FROM dbo.Products
where CategoryID = @IdKategorii)
go

