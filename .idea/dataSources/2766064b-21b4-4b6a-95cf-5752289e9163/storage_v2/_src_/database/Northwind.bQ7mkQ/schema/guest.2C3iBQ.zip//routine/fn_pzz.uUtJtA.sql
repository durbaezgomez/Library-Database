create function fn_pzz (@FreightParm money)
returns @OrderShipperTab table
(
ShipperID int,
ShipperName nvarchar(80),
OrderID int,
ShippedDate datetime,
Freight money)
as
begin
insert into @OrderShipperTab
select s.shipperid, s.companyname, o.orderid, o.shippeddate, o.freight
from shippers as s inner join orders as o
on s.shipperid = o.shipvia
where o.freight > @FreightParm
return 
end
go

