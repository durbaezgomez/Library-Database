create procedure p_jakasprzedazproduktuuu
@idproduct int=0,
@total money output
as
select @total = sum(round(od.quantity * od.unitprice * cast((1-od.discount)as money),2))
from [Order Details] as od
where productid = @idproduct
go

