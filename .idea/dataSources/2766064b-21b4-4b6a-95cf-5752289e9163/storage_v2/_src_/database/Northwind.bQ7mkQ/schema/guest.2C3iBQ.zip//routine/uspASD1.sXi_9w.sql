CREATE PROC uspASD1 (@Cena MONEY)
AS
SELECT*FROM dbo.Products
WHERE UnitPrice>=@Cena
ORDER BY UnitPrice DESC, ProductName
go

