create view vw_pzzz as select customerid, companyname from customers where region = 'WA'
go

