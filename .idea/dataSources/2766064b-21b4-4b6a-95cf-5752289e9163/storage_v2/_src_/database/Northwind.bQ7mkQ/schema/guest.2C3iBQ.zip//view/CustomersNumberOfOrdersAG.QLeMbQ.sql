CREATE VIEW CustomersNumberOfOrdersAG(CustomerID, NumberOfOrders)
AS
SELECT CustomerID, COUNT(*)
FROM Orders
GROUP BY CustomerID

go

