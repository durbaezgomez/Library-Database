CREATE PROC ASD1
AS
DECLARE @maksCena MONEY
SET @maksCena=(SELECT MAX(unitPrice) FROM Products)
SELECT*FROM Products
WHERE UnitPrice =@MaksCena
go

