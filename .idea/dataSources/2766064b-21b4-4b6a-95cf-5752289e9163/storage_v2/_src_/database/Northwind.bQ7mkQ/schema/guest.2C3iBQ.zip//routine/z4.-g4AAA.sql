create proc z4
as 
declare @maksCena money
set @maksCena = (select max(UnitPrice) from Products)
select * from Products where UnitPrice = @maksCena
go

