create proc W1
as
declare @maksCena money
set @maksCena = (select max(UnitPrice) from Products)
go

