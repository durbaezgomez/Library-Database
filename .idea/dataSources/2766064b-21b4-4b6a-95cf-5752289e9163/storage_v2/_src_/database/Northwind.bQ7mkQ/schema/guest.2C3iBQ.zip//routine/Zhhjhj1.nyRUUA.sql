 

create PROC Zhhjhj1
as
declare @makscena Money
set @makscena = (select MAX(UnitPrice) from Products)
select * from Products
where UnitPrice = @makscena
go

