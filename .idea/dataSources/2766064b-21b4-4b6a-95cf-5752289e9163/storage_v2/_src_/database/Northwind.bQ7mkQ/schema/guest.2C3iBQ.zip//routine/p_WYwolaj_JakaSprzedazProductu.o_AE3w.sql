CREATE PROCEDURE p_WYwolaj_JakaSprzedazProductu

	@IDProduct int 
as
	declare @Total_sum money
	exec p_WYwolaj_JakaSprzedazProductu @IDProduct ,@Total_sum output
	select @Total_sum
go

