create proc uspZ5 (@Cena Money)
as
select * from dbo.Products
where UnitPrice>=@Cena
order by UnitPrice DESC, ProductName
go

