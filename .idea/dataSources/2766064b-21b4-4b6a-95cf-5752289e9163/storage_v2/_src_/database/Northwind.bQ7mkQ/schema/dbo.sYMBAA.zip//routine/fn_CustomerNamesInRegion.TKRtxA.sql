create function dbo.fn_CustomerNamesInRegion (@RegionParameter nvarchar(30))
returns table
as
return (
		select CustomerID, CompanyName
		from Northwind.dbo.Customers
		where Region = @RegionParameter
		)
go

