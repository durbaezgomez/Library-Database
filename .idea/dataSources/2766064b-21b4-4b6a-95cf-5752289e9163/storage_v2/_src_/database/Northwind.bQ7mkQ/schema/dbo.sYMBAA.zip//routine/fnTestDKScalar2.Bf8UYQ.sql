CREATE FUNCTION dbo.fnTestDKScalar2 (@arg1 INT) RETURNS INT
BEGIN
	IF @arg1 = 1 return 1
	ELSE RETURN dbo.fnTestDKScalar2(@arg1 - 1)
	RETURN 0
END
go

