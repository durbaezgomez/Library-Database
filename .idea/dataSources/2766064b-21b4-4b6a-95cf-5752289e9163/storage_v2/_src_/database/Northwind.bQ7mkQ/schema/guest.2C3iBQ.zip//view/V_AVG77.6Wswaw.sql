create view V_AVG77(Average)
as
select avg(K2) from T1
go

