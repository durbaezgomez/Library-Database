CREATE PROC uspZ1asdad (@Cena MONEY)
AS
SELECT * FROM Products
WHERE UnitPrice >= @Cena
ORDER BY UnitPrice DESC, Productname
go

