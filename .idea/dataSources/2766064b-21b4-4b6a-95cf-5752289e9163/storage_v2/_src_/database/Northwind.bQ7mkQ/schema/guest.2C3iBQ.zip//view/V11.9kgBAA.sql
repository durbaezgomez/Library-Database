CREATE VIEW V11
AS
SELECT ProductID, ProductName, unitPrice
FROM Products
WHERE ProductName LIKE 'A%'
go

