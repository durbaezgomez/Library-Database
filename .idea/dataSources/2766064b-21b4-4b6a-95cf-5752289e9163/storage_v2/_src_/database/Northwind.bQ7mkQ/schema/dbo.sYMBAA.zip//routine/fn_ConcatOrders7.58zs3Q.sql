 CREATE FUNCTION dbo.fn_ConcatOrders7
	(@cid AS NCHAR(5)) RETURNS VARCHAR(8000)
AS
BEGIN
	DECLARE @orders AS VARCHAR(8000);
	SET @orders = '';
	
	SELECT @orders = @orders + CAST(OrderID AS VARCHAR(10)) + ';'
	FROM dbo.Orders
	WHERE CustomerID = @cid; 
	
	RETURN @orders;
END
 go

