create view v1234
as
select ProductId, ProductName,UnitPrice
from Products
where ProductName like 'A%'
go

