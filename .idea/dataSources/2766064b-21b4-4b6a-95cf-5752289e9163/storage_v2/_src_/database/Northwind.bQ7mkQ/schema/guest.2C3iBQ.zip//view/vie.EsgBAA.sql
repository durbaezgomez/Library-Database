create view vie as
select ProductID ,ProductName,UnitPrice
from Products
where ProductName Like 'A%'
go

