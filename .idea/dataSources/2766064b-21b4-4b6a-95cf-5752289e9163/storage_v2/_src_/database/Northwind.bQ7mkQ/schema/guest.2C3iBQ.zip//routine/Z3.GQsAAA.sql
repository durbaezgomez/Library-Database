CREATE PROC Z3
AS
DECLARE @maksCena2 MONEY
SET @maksCena2 = (SELECT MAX(UnitPrice) FROM Products)
go

