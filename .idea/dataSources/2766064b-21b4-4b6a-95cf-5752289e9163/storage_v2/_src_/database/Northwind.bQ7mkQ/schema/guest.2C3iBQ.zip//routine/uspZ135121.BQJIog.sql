Create Proc uspZ135121 (@Cena Money)
AS
Select * from dbo.Products
where UnitPrice >= @Cena
Order by UnitPrice desc
go

