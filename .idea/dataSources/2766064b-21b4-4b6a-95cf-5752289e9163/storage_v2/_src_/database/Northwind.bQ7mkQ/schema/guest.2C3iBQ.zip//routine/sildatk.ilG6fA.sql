create proc sildatk
as declare @makscena money
set @makscena = (select max(unitprice) from products)
--go
--select * from products
--where unitprice = @maxcena
go

