CREATE PROC uspZ243 (@NazwaKategorii NVARCHAR(15), @Ile INT OUT)
AS 
DECLARE @IdKategorii INT
DECLARE @MaksCena MONEY
SET @IdKategorii = (SELECT CategoryID FROM Categories 
WHERE CategoryName = @NazwaKategorii)
SET @MaksCena = (SELECT MAX(UnitPrice) FROM dbo.Products
WHERE CategoryID = @IdKategorii)

go

