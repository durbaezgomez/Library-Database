/*create view CustomerAndTotals (CustomerID,Total)
as 
select CustomerID,sum(round(Quantity*UnitPrice*
cast((1-Discount)as money),2))
from [Order Details] OD join Orders O
on OD.OrderID=O.OrderID
group by CustomerID

create view CustomerNumberOfOrders (CustomerID,NumberOfOrders)
as
select CustomerID,count(*)
from Orders 
group by CustomerID


select CompanyName 
from Suppliers
union
select CompanyName
from Customers
*/

/*T7 T8*/
create view VT1
as 
select * from T7
where K1>1
go

