CREATE PROCEDURE p_JakaSprzedazProduktu3
@IDProduct int = 0,
@Total money OUTPUT
AS
SELECT @Total = SUM(ROUND(OD.Quantity * OD.UnitPrice * CAST((1-OD.Discount)AS money),2))
FROM [Order Details] AS OD
WHERE ProductID= @IDProduct
go

