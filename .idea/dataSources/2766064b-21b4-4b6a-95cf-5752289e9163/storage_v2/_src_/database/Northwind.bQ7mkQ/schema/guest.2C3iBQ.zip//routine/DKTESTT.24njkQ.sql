CREATE PROC DKTESTT(@CategoryName VARCHAR(15), @T INT OUTPUT) AS 
SELECT * FROM Products P LEFT JOIN Categories C ON P.CategoryID = C.CategoryID WHERE @CategoryName = C.CategoryName;
go

