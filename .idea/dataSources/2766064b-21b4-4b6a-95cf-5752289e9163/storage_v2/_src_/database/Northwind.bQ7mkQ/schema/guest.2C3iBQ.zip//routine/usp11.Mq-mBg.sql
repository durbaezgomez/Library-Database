CREATE PROC usp11 (@nazwakategorii NVARCHAR(15), @ile INT OUTPUT)
AS 
DECLARE @Idkategorii INT
DECLARE @makscena MONEY
go

