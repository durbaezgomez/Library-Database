create proc uspW13 (@NazwaKategorii nvarchar(15), @Ile int output)
as 
declare @IdKategorii int
declare @MaksCena money

set @IdKategorii = (select CategoryID from Categories 
					where CategoryName=@NazwaKategorii)

set @MaksCena = (select max(UnitPrice) from Products
				 where CategoryID=@IdKategorii)

select * from Products
where CategoryID=@IdKategorii and UnitPrice=@MaksCena

set @ile = (select count(*) from Products
			where CategoryID=@IdKategorii)
go

