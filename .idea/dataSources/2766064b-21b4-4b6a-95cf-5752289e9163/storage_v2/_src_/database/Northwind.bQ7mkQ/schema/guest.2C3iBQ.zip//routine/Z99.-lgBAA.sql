CREATE PROC Z99
AS
DECLARE @maksCena MONEY
SET @maksCena = (SELECT MAX(UnitPrice) FROM Products)
SELECT * FROM Products
WHERE UnitPrice = @MaksCena
go

