create proc uspZ12(@Cena Money)
as 
select * from dbo.Products
where UnitPrice >= @Cena
order by UnitPrice desc, ProductName
go

