create procedure dbo.p_wywolaj_jakasprzedazproduktu
@idproduct int
as
declare @total_sum money
exec p_jakasprzedazproduktu @idproduct, @total_sum out
select @total_sum
go

