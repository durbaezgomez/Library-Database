create procedure dbo.p_wywolaj_jakasprzedazproduktuuu
@idproduct int
as
declare @total_sum money
exec  p_jakasprzedazproduktuuu @idproduct, @total_sum output
select @total_sum
go

