create proc uspzz2 (@nazwakategorii nvarchar(15), @ile int output)
as
declare @idkategorii int
declare @makscena money
set @idkategorii = (select categoryid from categories where categoryname = @nazwakategorii)
set @makscena = (select max(unitprice) from dbo.Products where categoryid = @idkategorii)
go

