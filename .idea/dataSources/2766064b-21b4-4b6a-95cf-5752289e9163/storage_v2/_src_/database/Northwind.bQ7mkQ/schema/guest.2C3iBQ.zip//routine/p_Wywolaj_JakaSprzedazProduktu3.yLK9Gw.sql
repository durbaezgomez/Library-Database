CREATE PROCEDURE p_Wywolaj_JakaSprzedazProduktu3
@IDProduct int
AS
DECLARE @Total_sum money
EXEC p_JakaSprzedazProduktu3 @IDProduct, @Total_sum OUT
SELECT @Total_sum
go

