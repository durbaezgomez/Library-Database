Create Proc uspZ1351 (@Cena Money)
AS
Select * from dbo.Products
where UnitPrice >= @Cena
Order by UnitPrice desc, ProductName
go

