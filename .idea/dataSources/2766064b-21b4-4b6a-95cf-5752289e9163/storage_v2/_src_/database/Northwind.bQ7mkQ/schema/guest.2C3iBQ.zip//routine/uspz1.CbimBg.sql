create proc uspz1 (@Cena money)
as
select * from dbo.Products
where UnitPrice >= @Cena
order by UnitPrice desc, ProductName
go

