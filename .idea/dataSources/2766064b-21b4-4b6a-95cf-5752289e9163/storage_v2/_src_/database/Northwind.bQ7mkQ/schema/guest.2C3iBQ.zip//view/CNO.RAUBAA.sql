Create View CNO (CustomerID, NumberOfOrders)
AS
Select CustomerID, Count(*)
from Orders
GROUP BY CustomerID
go

