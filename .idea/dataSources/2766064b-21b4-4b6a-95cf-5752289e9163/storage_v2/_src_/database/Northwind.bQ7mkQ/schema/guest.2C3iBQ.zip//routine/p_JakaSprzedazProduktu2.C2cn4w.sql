create procedure p_JakaSprzedazProduktu2
@IDProduct int = 0,
@Total money output
as 
select @Total = sum(round(od.quantity * od.UnitPrice * cast((1 - od.Discount) as money),2))
from [Order Details] as od
where ProductID = @IDProduct
go

