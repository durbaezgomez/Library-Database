--Select ProductID, Productname, UnitPrice
--FROM Products
--Where ProductName Like 'A%'

CREATE VIEW V12
AS
Select ProductID, Productname, UnitPrice
FROM Products
Where ProductName Like 'A%'
go

