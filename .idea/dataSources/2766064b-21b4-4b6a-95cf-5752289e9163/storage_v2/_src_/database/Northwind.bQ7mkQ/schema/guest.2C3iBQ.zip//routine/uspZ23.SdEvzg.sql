CREATE PROC uspZ23 (@NazwaKategorii NVARCHAR(15), @Ile INT OUTPUT)

AS
DECLARE @IdKategorii INT
DECLARE @MaksCena MONEY

SET @IdKategorii = (SELECT CategoryID FROM Categories
WHERE CategoryName = @NazwaKategorii)

SET @MaksCena = (SELECT MAX(UnitPrice) FROM Products
WHERE CategoryID=@IdKategorii)

SELECT * FROM Products
WHERE CategoryID=@IdKategorii AND UnitPrice=@MaksCena

SET @Ile = (SELECT COUNT(*) FROM Products
WHERE CategoryID=@IdKategorii)
go

