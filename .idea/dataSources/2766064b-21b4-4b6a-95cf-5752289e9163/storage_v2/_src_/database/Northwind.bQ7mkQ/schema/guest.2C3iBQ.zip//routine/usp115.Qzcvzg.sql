CREATE PROC usp115 (@nazwakategorii NVARCHAR(15), @ile INT OUTPUT)
AS 
DECLARE @Idkategorii INT
DECLARE @makscena MONEY

SET @Idkategorii =(SELECT CategoryID FROM Categories
WHERE CategoryName=@nazwakategorii)
--SELECT @Idkategorii=categoryID
--FROM Categories WHERE CategoryName=@nazwakategorii

SET @makscena=(SELECT MAX(UnitPrice) FROM dbo.Products
WHERE CategoryID=@Idkategorii)

SELECT * FROM Products
WHERE CategoryID=@Idkategorii AND UnitPrice=@makscena
SET @ile = (SELECT COUNT(*) FROM Products
WHERE CategoryID=@Idkategorii)
go

