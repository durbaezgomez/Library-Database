create view  CustomersAndTotalsSD(CustomerId, Total)
as
select CustomerId,
SUM(round(quantity*UnitPrice*CAST((1-Discount)As money),2))
from [Order Details] OD join Orders O
on od.orderid = o.orderid
group by customerid
go

