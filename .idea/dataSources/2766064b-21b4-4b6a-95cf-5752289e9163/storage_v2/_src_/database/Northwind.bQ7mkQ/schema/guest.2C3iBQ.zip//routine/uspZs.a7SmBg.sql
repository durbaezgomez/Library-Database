create proc uspZs (@Cena Money)
As
Select * from dbo.Products
where UnitPrice >= @Cena
order by UnitPrice Desc, ProductName
go

