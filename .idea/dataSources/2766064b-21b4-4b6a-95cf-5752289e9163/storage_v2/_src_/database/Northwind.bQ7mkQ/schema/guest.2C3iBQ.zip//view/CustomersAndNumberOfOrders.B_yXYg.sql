create view CustomersAndNumberOfOrders (customerid, numberoforders)
as
select customerid, count(*)
from orders
group by customerid
go

