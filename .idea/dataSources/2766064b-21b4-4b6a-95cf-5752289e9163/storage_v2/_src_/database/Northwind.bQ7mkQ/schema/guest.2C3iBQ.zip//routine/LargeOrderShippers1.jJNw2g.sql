create function LargeOrderShippers1 (@FreightParm money)
returns @OrderShipperTab TABLE
(
	ShipperID int,
	ShipperName nvarchar(80),
	OrderID int,
	ShippedDate datetime,
	Freight money
)
as
begin
	insert into @OrderShipperTab
		select S.ShipperID, S.CompanyName,
				O.OrderID, O.ShippedDate, O.Freight
		FROM	Shippers AS S inner join Orders AS O
				ON S.ShipperID = O.ShipVia
		where O.Freight > @FreightParm
	return 
end
go

