CREATE VIEW widok1
AS 
SELECT  ProductID, ProductName, UnitPrice
FROM Products
WHERE ProductName Like 'A%'
go

