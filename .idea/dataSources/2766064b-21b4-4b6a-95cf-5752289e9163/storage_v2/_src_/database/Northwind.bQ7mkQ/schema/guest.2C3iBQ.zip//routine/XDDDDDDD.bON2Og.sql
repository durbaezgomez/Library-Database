CREATE PROC XDDDDDDD AS 
DECLARE @maxCena MONEY
SET @maxCena = (SELECT MAX(UnitPrice) FROM Products)
SELECT * FROM Products WHERE UnitPrice = @maxCena
go

