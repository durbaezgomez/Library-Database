create proc uspZhhjhj4(@NazwaKategorii nvarchar(15), @ile int output)
as
declare @IdKategorii int
declare @makscena money

set @IdKategorii = (select CategoryID from Categories
where CategoryName=@NazwaKategorii)
go

