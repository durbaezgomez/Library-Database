CREATE FUNCTION dbo.fnTestDKScalar4 (@arg1 INT) RETURNS INT
BEGIN
	IF @arg1 = 1 return 1
	IF @arg1 = 2 return 1
	ELSE RETURN dbo.fnTestDKScalar4(@arg1 - 2) + dbo.fnTestDKScalar4(@arg1 - 1)
	RETURN 0
END
go

