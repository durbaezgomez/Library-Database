create function fn_pzzzzz (@RegionParameter nvarchar(30)) 
returns table 
as
return (
select customerid, companyname
from customers where region = @RegionParameter)
go

