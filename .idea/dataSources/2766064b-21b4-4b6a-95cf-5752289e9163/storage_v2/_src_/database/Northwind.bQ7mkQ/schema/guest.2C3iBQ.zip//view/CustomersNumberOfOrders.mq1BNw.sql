/*create view CustomersAndTotals (CustomerID, Total)
as
select CustomerID, sum(round(quantity*unitprice*cast((1-discount) as money), 2)) from [Order Details] od join orders o on od.orderid = o.orderid group by customerid*/

create view CustomersNumberOfOrders (CustomerID, NumberOfOrders) as select CustomerID, COUNT(*) from Orders Group by CustomerID
go

