CREATE PROC usp22 (@nazwakategorii NVARCHAR(15), @ile INT OUTPUT)
AS 
DECLARE @Idkategorii INT
DECLARE @makscena MONEY
go

