create proc uspZ2 (@NazwaKategorii nvarchar(15), @Ile INT output)
as 
declare @IdKategorii INT
declare @MaksCena Money
go

