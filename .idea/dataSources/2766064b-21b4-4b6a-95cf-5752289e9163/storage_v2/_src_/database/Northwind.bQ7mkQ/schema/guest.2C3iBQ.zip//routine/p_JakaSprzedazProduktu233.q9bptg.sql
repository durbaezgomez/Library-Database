create Procedure p_JakaSprzedazProduktu233
	@IDProduct int  = 0,
	@Total money output 
as 
	select @Total = sum(round(Od.Quantity * od.UnitPrice * cast((1-Od.Discount) as money),2))
	from [Order Details] as OD
	where ProductID = @IDProduct
go

