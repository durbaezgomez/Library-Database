create function LargeeeeOrderShippers (@FreightPram money)
returns @OrderShipperTab table
(
	ShipperID int,
	ShipperName nvarchar(80),
	OrderID int,
	ShippedDate datetime,
	Freight money
)
as
begin
	insert into @OrderShipperTab
		select S.ShipperID, S.CompanyName,
				O.OrderID, O.ShippedDate, O.Freight
		from Shippers as S inner join Orders as O
				on s.ShipperID = O.ShipVia
		where O.Freight > @FreightPram
	return
end
go

