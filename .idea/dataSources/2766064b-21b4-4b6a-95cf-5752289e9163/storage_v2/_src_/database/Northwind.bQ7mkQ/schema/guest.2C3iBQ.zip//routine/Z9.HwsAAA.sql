
create proc Z9 
as
declare @maksCena money
set @maksCena = (Select max(UnitPrice) from Products)

go

