CREATE PROCEDURE p_Wywolaj_JakaSprzedazProduktu22
	@IDProduct INT
	AS
	DECLARE @Total_sum MONEY
	EXEC p_JakaSprzedazProduktu22 @IDProduct, @Total_sum OUTPUT
	SELECT @Total_sum
go

