
CREATE VIEW XD(XD, XDD, XDDD) AS
SELECT ProductID, ProductName, UnitPrice
FROM Products
WHERE ProductName LIKE 'A%';
go

