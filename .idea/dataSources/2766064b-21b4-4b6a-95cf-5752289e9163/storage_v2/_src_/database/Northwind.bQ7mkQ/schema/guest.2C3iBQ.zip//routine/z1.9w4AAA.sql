create proc z1
as
declare @MaksCena money
set @MaksCena = (select max(UnitPrice) from Products)
select * from Products
where UnitPrice = @MaksCena
go

