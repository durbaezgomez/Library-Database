--WITH MyCTE (NrProduktu, Nazwa)
--AS
--(
--SELECT ProductID,ProductName FROM Products
--WHERE CategoryID = 1
--)
--SELECT COUNT(*) FROM MyCTE
--WHERE Nazwa LIKE 'C%'

--CREATE PROC yomama
--AS
--DECLARE @maksCena MONEY
--SET @maksCena = (SELECT MAX(UnitPrice) FROM Products)
--SELECT * FROM Products
--WHERE UnitPrice = @maksCena
--GO

--exec yomama

--IF OBJECT_ID('uspZ1','P') IS NOT NULL
--DROP PROC dbo.uspZ1

--exec uspZ1 20

--CREATE FUNCTION DuzeZamowienieStatki (@Freigt money)
--RETURNS @ZamowienieStatekTab TABLE
--	(
--	 ShipperID int,
--	 ShipperName nvarchar(80),
--	 OrderID int,
--	 ShippedDate datetime,
--	 Freight money
--	)
--AS
--BEGIN
--INSERT INTO @ZamowienieStatekTab
--	SELECT S.ShipperID,S.CompanyName,O.OrderID,O.ShippedDate,O.Freight FROM Shippers S JOIN Orders O
--	ON S.ShipperID = O.ShipVia 
--	WHERE O.Freight > @Freigt
--	RETURN
--END
--GO

--SELECT * FROM DuzeZamowienieStatki($500)

CREATE FUNCTION KlientImionaWRegionie (@region nvarchar(30))
RETURNS TABLE
AS
RETURN
(
 SELECT CustomerID, CompanyName
 FROM Customers
 WHERE Region = @region
)
go

