CREATE PROCEDURE p_JakaSprzedazProduktu22
@IDProduct INT = 0,
@Total MONEY OUTPUT

AS
	SELECT @Total = SUM(ROUND(OD.Quantity*OD.UnitPrice * CAST((1-OD.Discount) AS MONEY), 2))
	FROM [Order Details] AS OD
	WHERE ProductID = @IDProduct
go

