CREATE PROC uspZhhjhj1(@CENA MONEY)
AS
SELECT * from dbo.Products
where UnitPrice>=@CENA
order by UnitPrice desc, ProductName
go

