
create procedure ezz_pzz
@IDProduct int
as
declare @Total_sum money
exec ez_pz @IDProduct, @Total_sum output
go

