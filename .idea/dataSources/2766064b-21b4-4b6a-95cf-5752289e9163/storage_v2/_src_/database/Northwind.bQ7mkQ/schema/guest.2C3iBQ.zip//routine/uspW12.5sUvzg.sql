create proc uspW12 (@Cena money)
as 
select * from Products
where UnitPrice >= @Cena
order by UnitPrice desc, ProductName
go

