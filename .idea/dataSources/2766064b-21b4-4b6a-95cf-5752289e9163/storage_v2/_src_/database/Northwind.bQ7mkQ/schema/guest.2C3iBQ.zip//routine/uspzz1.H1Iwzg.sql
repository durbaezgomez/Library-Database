create proc uspzz1 (@cena money)
as
select * from dbo.Products
where unitprice >= @cena
order by unitprice desc, productname
go

