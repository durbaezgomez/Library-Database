CREATE VIEW XDD(XD, XDD, XDDD) AS
SELECT ProductID, ProductName, UnitPrice
FROM Products;
go

