create function dbo.fn_ContactOrders
(@cid as Nchar(5)) Returns varchar(8000)
as
begin
declare @orders as Varchar(8000)
set @orders = ''
select @orders = @orders + Cast(OrderId as Varchar(10))+ ','
from dbo.Orders
where CustomerId=@cid
return @orders
end
go

