create view V3
as
	Select ProductID, ProductName, UnitPrice
	from Products
	where ProductName Like 'A%';
go

